// src/hooks/useChat.ts
'use client';
import { useContext } from 'react';
import { ChatContext } from '@/context/ChatContext';

export function useChat() {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}